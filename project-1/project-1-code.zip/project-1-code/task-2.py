import matplotlib.pyplot as plt
import pyspark.sql.functions as F
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("task-1") \
    .getOrCreate()
sc = spark.sparkContext

df_playlist = spark.read.json(
    "hdfs://localhost:9000/datasets/spotify/playlist.json")
df_tracks_clean = spark.read.json(
    'hdfs://localhost:9000//user/zz229/project-1/tracks_clean.json')

df_joined = df_tracks_clean.join(df_playlist, 'pid')

df_joined = df_joined.withColumn(
    'year', F.from_unixtime('modified_at', 'yyyy'))

df_joined = df_joined.groupBy(['artist_name', 'year']).agg(
    F.count_distinct('pid').alias('playlist_count')).sort(F.asc('artist_name'))

df_total_playlist_cnt = df_joined.groupBy('artist_name').agg(F.sum(
    'playlist_count').alias('total_playlist_count')).sort(F.desc('total_playlist_count'))

df_top_5_artist = df_total_playlist_cnt.limit(5).join(
    df_joined, 'artist_name', how='left')

# plot the number of playlists containing each of these five artists over the years
pd_top_5_artist = df_top_5_artist.toPandas()

plt.figure(dpi=150)
for name, group in pd_top_5_artist.sort_values(['total_playlist_count', 'year']).groupby('artist_name'):
    plt.plot(group['year'].astype(int), group['playlist_count'], label=name)

plt.legend()
plt.xlabel('Year')
plt.ylabel('Number of playlists')
plt.title('Number of playlists containing each of these five artists over the years')

plt.savefig('/home/zz229/project-1/top_5_artist.png')

sc.stop()
