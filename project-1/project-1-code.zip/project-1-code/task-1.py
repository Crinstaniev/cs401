import pyspark.sql.functions as F
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("task-1") \
    .getOrCreate()
sc = spark.sparkContext

df_tracks = spark.read.json(
    "hdfs://localhost:9000/datasets/spotify/tracks.json")
df_playlist = spark.read.json(
    "hdfs://localhost:9000/datasets/spotify/playlist.json")

df_original_statistics = df_tracks.select(
    F.min('duration_ms').alias('min'),
    F.mean('duration_ms').alias('average'),
    F.max('duration_ms').alias('max')
)

df_original_statistics.write.mode('overwrite').json(
    'hdfs://localhost:9000//user/zz229/project-1/orignal_statistics.json')

df_iq_tracks = df_tracks.select(
    F.expr("percentile(duration_ms, 0.25)"),
    F.expr("percentile(duration_ms, 0.5)"),
    F.expr("percentile(duration_ms, 0.75)")
).toDF('q1', 'median', 'q3').withColumn('iqr', F.col('q3') - F.col('q1'))

df_iq_tracks.write.mode('overwrite').csv('hdfs://localhost:9000//user/zz229/project-1/iq_tracks.csv')

lower_bound = df_iq_tracks.select(
    F.col('q1') - 1.5 * F.col('iqr')).collect()[0][0]
upper_bound = df_iq_tracks.select(
    F.col('q3') + 1.5 * F.col('iqr')).collect()[0][0]

df_tracks_clean = df_tracks.filter(
    (F.col('duration_ms') > lower_bound) &
    (F.col('duration_ms') < upper_bound)
)

df_tracks_clean.write.mode('overwrite').json(
    'hdfs://localhost:9000//user/zz229/project-1/tracks_clean.json')

num_songs_removed = df_tracks.count() - df_tracks_clean.count()
print("Number of songs removed: {}".format(num_songs_removed))
with open('/home/zz229/project-1/num_songs_removed.txt', 'w') as f:
    f.write("Number of songs removed: {}".format(num_songs_removed))

df_remaining_statistics = df_tracks_clean.select(
    F.min('duration_ms').alias('min'),
    F.mean('duration_ms').alias('average'),
    F.max('duration_ms').alias('max')
)

df_remaining_statistics.write.mode('overwrite').json(
    "hdfs://localhost:9000//user/zz229/project-1/remaining_statistics.json")

sc.stop()
