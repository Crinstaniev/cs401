import matplotlib.pyplot as plt
import pyspark.sql.functions as F
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("task-1") \
    .getOrCreate()
sc = spark.sparkContext

df_playlist = spark.read.json(
    "hdfs://localhost:9000/datasets/spotify/playlist.json")
df_tracks_clean = spark.read.json(
    'hdfs://localhost:9000//user/zz229/project-1/tracks_clean.json')

df_joined = df_tracks_clean.join(df_playlist, 'pid')

# calculate the most frequent artiest in each playlist
# group by pid and artist_name, count the total song number
df_playlist_artist_cnt = df_joined.groupBy('pid', 'artist_name') \
    .agg(F.count('artist_name').alias('num_songs_artist')) \
    .groupBy('pid').agg(F.max('num_songs_artist').alias('num_songs_max_artist'))
df_playlist_songs_cnt = df_joined.groupBy('pid') \
    .agg(F.count('pid').alias('num_songs_total'))

df_playlist_stats = df_playlist_artist_cnt.join(df_playlist_songs_cnt, 'pid') \
    .withColumn('ratio', F.col('num_songs_max_artist') / F.col('num_songs_total'))


freq = df_playlist_stats.select('ratio').rdd.flatMap(lambda x: x).collect()

# plot the freq to CDF
plt.figure(dpi=150)
plt.hist(freq, bins=5000, cumulative=True, density=True, histtype='step')
plt.xlabel('Ratio of the most frequent artist in each playlist')
plt.ylabel('CDF')
plt.title('CDF of prevalence of the most frequent artist in each playlist')
plt.savefig('/home/zz229/project-1/artist_prevalence_cdf.png')

sc.stop()